"use client";

import Chapter8Diagram from "@/components/maths/Chapter8Geometry";

import { useRouter } from "next/navigation";

export default function DistanceBetweenTwoPointsPage() {
  const router = useRouter();

  return (
    <main className="page">
      <button
        type="button"
        className="backButton"
        onClick={() => router.push("/maths/s1/chapter-8")}
      >
        ← Back to Chapter 8
      </button>

      <p className="eyebrow">S1 · CHAPTER 8 · SECTION 2</p>
      <h1>Distance between Two Points</h1>

      <p className="introduction">
        Compare the coordinates of two points on the same horizontal or
        vertical line. Distance is always a non-negative length.
      </p>

      <section className="lessonCard">
        <div className="lessonHeading">
          <span className="lessonNumber">1</span>
          <div>
            <p className="lessonLabel">READ THE DIRECTION</p>
            <h2>First identify which coordinate stays the same</h2>
          </div>
        </div>

        <div className="directionGrid">
          <article>
            <Chapter8Diagram kind="horizontal" />
            <h3>Horizontal line</h3>
            <strong>Compare the x-coordinates</strong>
            <p>The y-coordinates are equal.</p>
          </article>

          <article>
            <Chapter8Diagram kind="vertical" />
            <h3>Vertical line</h3>
            <strong>Compare the y-coordinates</strong>
            <p>The x-coordinates are equal.</p>
          </article>
        </div>

        <div className="keyNote">
          <strong>Only one coordinate changes.</strong>
          <span>The changing coordinate determines the distance.</span>
        </div>
      </section>

      <section className="lessonCard workedCard">
        <div className="lessonHeading">
          <span className="lessonNumber">2</span>
          <div>
            <p className="lessonLabel">HORIZONTAL DISTANCE</p>
            <h2>Subtract the x-coordinates</h2>
          </div>
        </div>

        <div className="formulaBanner">
          <span>P(x₁, y)</span>
          <strong>PQ = |x₂ − x₁|</strong>
          <span>Q(x₂, y)</span>
        </div>

        <div className="workedLayout">
          <Chapter8Diagram kind="horizontal-example" />

          <div className="workedSteps">
            <article>
              <span>1</span>
              <div>
                <p>Confirm that the points are horizontal.</p>
                <strong>Both y-coordinates are 3.</strong>
              </div>
            </article>
            <article>
              <span>2</span>
              <div>
                <p>Subtract the x-coordinates.</p>
                <strong>|5 − (−4)|</strong>
              </div>
            </article>
            <article>
              <span>3</span>
              <div>
                <p>Evaluate the absolute value.</p>
                <strong>PQ = |9| = 9 units</strong>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="lessonCard workedCard verticalCard">
        <div className="lessonHeading">
          <span className="lessonNumber">3</span>
          <div>
            <p className="lessonLabel">VERTICAL DISTANCE</p>
            <h2>Subtract the y-coordinates</h2>
          </div>
        </div>

        <div className="formulaBanner verticalFormula">
          <span>R(x, y₁)</span>
          <strong>RS = |y₂ − y₁|</strong>
          <span>S(x, y₂)</span>
        </div>

        <div className="workedLayout">
          <Chapter8Diagram kind="vertical-example" />

          <div className="workedSteps">
            <article>
              <span>1</span>
              <div>
                <p>Confirm that the points are vertical.</p>
                <strong>Both x-coordinates are 2.</strong>
              </div>
            </article>
            <article>
              <span>2</span>
              <div>
                <p>Subtract the y-coordinates.</p>
                <strong>|4 − (−5)|</strong>
              </div>
            </article>
            <article>
              <span>3</span>
              <div>
                <p>Evaluate the absolute value.</p>
                <strong>RS = |9| = 9 units</strong>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="lessonCard">
        <div className="lessonHeading">
          <span className="lessonNumber">4</span>
          <div>
            <p className="lessonLabel">DISTANCE FROM AN AXIS</p>
            <h2>Use the absolute value of one coordinate</h2>
          </div>
        </div>

        <div className="axisDistanceLayout">
          <Chapter8Diagram kind="axis-distance" />

          <div className="axisRuleGrid">
            <article>
              <span>|x|</span>
              <strong>Distance from the y-axis</strong>
              <p>For T(−6, 2), the distance is |−6| = 6 units.</p>
            </article>
            <article>
              <span>|y|</span>
              <strong>Distance from the x-axis</strong>
              <p>For T(−6, 2), the distance is |2| = 2 units.</p>
            </article>
          </div>
        </div>

        <div className="keyNote axisKeyNote">
          <strong>A coordinate may be negative, but a distance cannot be negative.</strong>
        </div>
      </section>

      <section className="lessonCard">
        <div className="lessonHeading">
          <span className="lessonNumber">5</span>
          <div>
            <p className="lessonLabel">SIDE LENGTHS ON A GRID</p>
            <h2>Coordinate differences reveal horizontal and vertical sides</h2>
          </div>
        </div>

        <div className="rectangleLayout">
          <Chapter8Diagram kind="distance-rectangle" />

          <div className="sideCalculations">
            <article>
              <span>Horizontal sides</span>
              <strong>AB = DC = |5 − (−3)| = 8 units</strong>
              <p>A and B share y = 4. D and C share y = −2.</p>
            </article>
            <article>
              <span>Vertical sides</span>
              <strong>BC = AD = |4 − (−2)| = 6 units</strong>
              <p>B and C share x = 5. A and D share x = −3.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="summaryCard">
        <p className="summaryLabel">SECTION SUMMARY</p>
        <h2>Distance rules</h2>

        <div className="summaryGrid">
          <article>
            <span>↔</span>
            <div>
              <strong>Horizontal</strong>
              <p>Same y-coordinate; subtract the x-coordinates.</p>
            </div>
          </article>
          <article>
            <span>↕</span>
            <div>
              <strong>Vertical</strong>
              <p>Same x-coordinate; subtract the y-coordinates.</p>
            </div>
          </article>
          <article>
            <span>| |</span>
            <div>
              <strong>Absolute value</strong>
              <p>Use absolute value so the distance is non-negative.</p>
            </div>
          </article>
          <article>
            <span>0</span>
            <div>
              <strong>From an axis</strong>
              <p>Distance from the y-axis is |x|; from the x-axis is |y|.</p>
            </div>
          </article>
        </div>
      </section>

      <button
        type="button"
        className="finishButton"
        onClick={() => router.push("/maths/s1/chapter-8")}
      >
        Finish Section 2 →
      </button>

      <style jsx>{`
        .page {
          max-width: 1120px;
          width: calc(100% - 48px);
          margin: 46px auto 72px;
          box-sizing: border-box;
          color: #172033;
        }

        .backButton {
          margin-bottom: 26px;
          padding: 0;
          border: none;
          background: transparent;
          color: #047857;
          font-size: 17px;
          font-weight: 800;
          cursor: pointer;
        }

        .eyebrow,
        .lessonLabel,
        .summaryLabel {
          font-size: 13px;
          font-weight: 900;
          letter-spacing: 0.1em;
        }

        .eyebrow {
          margin: 0 0 7px;
          color: #e11d48;
        }

        h1 {
          margin: 0;
          font-size: clamp(38px, 5vw, 54px);
          line-height: 1.1;
          letter-spacing: -0.035em;
        }

        .introduction {
          max-width: 840px;
          margin: 17px 0 30px;
          color: #5c667a;
          font-size: 19px;
          line-height: 1.6;
        }

        .lessonCard,
        .summaryCard {
          margin-top: 18px;
          padding: 28px;
          border: 1px solid #e2e8f0;
          border-radius: 23px;
          background: white;
          box-shadow: 0 7px 22px rgba(15, 23, 42, 0.045);
        }

        .lessonHeading {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 24px;
        }

        .lessonNumber {
          width: 50px;
          height: 50px;
          flex: 0 0 50px;
          display: grid;
          place-items: center;
          border-radius: 16px;
          background: #fff7ed;
          color: #c2410c;
          font-size: 21px;
          font-weight: 900;
        }

        .lessonLabel,
        .summaryLabel {
          margin: 0 0 5px;
          color: #c2410c;
        }

        .lessonHeading h2,
        .summaryCard h2 {
          margin: 0;
          font-size: 25px;
          line-height: 1.25;
        }

        .directionGrid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 16px;
        }

        .directionGrid article {
          padding: 18px;
          border: 1px solid #dbeafe;
          border-radius: 18px;
          background: #f8fbff;
          text-align: center;
        }

        .directionGrid svg {
          width: 100%;
          max-height: 150px;
        }

        .directionGrid h3 {
          margin: 8px 0 6px;
          font-size: 21px;
        }

        .directionGrid strong {
          color: #1e3a8a;
        }

        .directionGrid p {
          margin: 6px 0 0;
          color: #64748b;
        }

        .pointText,
        .diagramText,
        .distanceText,
        .axisText {
          font-family: Arial, sans-serif;
          font-weight: 800;
        }

        .pointText {
          fill: #be123c;
          font-size: 14px;
        }

        .diagramText,
        .distanceText {
          fill: #4338ca;
          font-size: 13px;
        }

        .axisText {
          fill: #172033;
          font-size: 14px;
        }

        .keyNote {
          display: flex;
          justify-content: center;
          gap: 10px;
          margin-top: 20px;
          padding: 15px;
          border-radius: 14px;
          background: #ecfdf5;
          color: #166534;
          text-align: center;
        }

        .workedCard {
          border-color: #bfdbfe;
          background: #fbfdff;
        }

        .verticalCard {
          border-color: #c7d2fe;
        }

        .formulaBanner {
          display: grid;
          grid-template-columns: 1fr auto 1fr;
          align-items: center;
          gap: 16px;
          margin-bottom: 22px;
          padding: 17px;
          border-radius: 15px;
          background: #eff6ff;
          color: #1e3a8a;
          text-align: center;
        }

        .formulaBanner strong {
          font-family: Georgia, "Times New Roman", serif;
          font-size: clamp(23px, 4vw, 34px);
        }

        .formulaBanner span {
          font-weight: 900;
        }

        .verticalFormula {
          background: #eef2ff;
          color: #3730a3;
        }

        .workedLayout,
        .axisDistanceLayout,
        .rectangleLayout {
          display: grid;
          grid-template-columns: minmax(0, 1.08fr) minmax(310px, 0.92fr);
          gap: 26px;
          align-items: center;
        }

        .coordinateDiagram,
        .axisDiagram,
        .rectangleDiagram {
          width: 100%;
          border-radius: 18px;
          background: white;
        }

        .workedSteps,
        .axisRuleGrid,
        .sideCalculations {
          display: grid;
          gap: 12px;
        }

        .workedSteps article {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px;
          border-radius: 15px;
          background: white;
        }

        .workedSteps article > span {
          width: 40px;
          height: 40px;
          flex: 0 0 40px;
          display: grid;
          place-items: center;
          border-radius: 12px;
          background: #dbeafe;
          color: #1d4ed8;
          font-size: 19px;
          font-weight: 900;
        }

        .workedSteps p,
        .axisRuleGrid p,
        .sideCalculations p {
          margin: 4px 0 0;
          color: #64748b;
          line-height: 1.45;
        }

        .workedSteps strong {
          display: block;
          margin-top: 4px;
          color: #1e3a8a;
        }

        .axisRuleGrid article,
        .sideCalculations article {
          padding: 19px;
          border: 1px solid #e2e8f0;
          border-radius: 17px;
          background: #f8fafc;
        }

        .axisRuleGrid article > span,
        .sideCalculations article > span {
          display: block;
          margin-bottom: 9px;
          color: #c2410c;
          font-size: 24px;
          font-weight: 900;
        }

        .axisRuleGrid strong,
        .sideCalculations strong {
          display: block;
          color: #172033;
          font-size: 17px;
        }

        .axisKeyNote {
          display: block;
        }

        .summaryCard {
          border-color: #c7d2fe;
          background: linear-gradient(135deg, #eef2ff, #faf5ff);
        }

        .summaryLabel {
          color: #4f46e5;
        }

        .summaryGrid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 12px;
          margin-top: 20px;
        }

        .summaryGrid article {
          display: flex;
          align-items: center;
          gap: 13px;
          padding: 16px;
          border-radius: 15px;
          background: white;
        }

        .summaryGrid article > span {
          width: 42px;
          height: 42px;
          flex: 0 0 42px;
          display: grid;
          place-items: center;
          border-radius: 12px;
          background: #e0e7ff;
          color: #4338ca;
          font-size: 18px;
          font-weight: 900;
        }

        .summaryGrid p {
          margin: 4px 0 0;
          color: #64748b;
          line-height: 1.4;
        }

        .finishButton {
          width: 100%;
          margin-top: 20px;
          padding: 16px;
          border: none;
          border-radius: 15px;
          background: #059669;
          color: white;
          font-size: 17px;
          font-weight: 900;
          cursor: pointer;
        }

        .finishButton:hover {
          background: #047857;
        }

        @media (max-width: 850px) {
          .workedLayout,
          .axisDistanceLayout,
          .rectangleLayout {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 680px) {
          .page {
            width: calc(100% - 24px);
            margin-top: 28px;
          }

          .lessonCard,
          .summaryCard {
            padding: 20px;
          }

          .directionGrid,
          .summaryGrid {
            grid-template-columns: 1fr;
          }

          .formulaBanner {
            grid-template-columns: 1fr;
          }

          .keyNote {
            align-items: flex-start;
            flex-direction: column;
          }
        }
      `}</style>
    </main>
  );
}
