"use client";
import { Straight, Crossing, Around, Parallel, Triangle, CheckpointDiagram } from "@/components/maths/Chapter9Geometry";
export type Chapter9FlashcardDiagramKind =
  | "straight-line"
  | "vertically-opposite"
  | "angles-at-point"
  | "corresponding"
  | "alternate"
  | "same-side-interior"
  | "converse-rules"
  | "triangle-angle-sum"
  | "triangle-exterior"
  | "triangle-exterior-example";


export default function Chapter9FlashcardDiagram({kind}:{kind:Chapter9FlashcardDiagramKind}){
 let drawing;
 switch(kind){
 case "straight-line":drawing=<Straight/>;break;
 case "vertically-opposite":drawing=<Crossing second="b"/>;break;
 case "angles-at-point":drawing=<Around/>;break;
 case "corresponding":case "alternate":drawing=<Parallel kind={kind}/>;break;
 case "same-side-interior":drawing=<Parallel kind="interior"/>;break;
 case "converse-rules":drawing=<Parallel converse/>;break;
 case "triangle-angle-sum":drawing=<Triangle kind="flash-sum"/>;break;
 case "triangle-exterior":drawing=<Triangle kind="flash-exterior"/>;break;
 case "triangle-exterior-example":drawing=<Triangle kind="flash-example"/>;break;
 }
 return <div style={{width:"100%",maxWidth:600,margin:"4px auto 12px",background:"white",borderRadius:16,border:"1px solid #dbe4ef"}}>{drawing}</div>;
}
