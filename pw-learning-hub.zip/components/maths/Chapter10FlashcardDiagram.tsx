"use client";
import {Pair} from "@/components/maths/Chapter10Geometry";
export type Chapter10FlashcardDiagramKind =
  | "c10-congruent-meaning"
  | "c10-correspondence"
  | "c10-equal-angles"
  | "c10-equal-sides"
  | "c10-similar-angle-question"
  | "c10-sss"
  | "c10-sas"
  | "c10-asa"
  | "c10-aas"
  | "c10-rhs"
  | "c10-similar-meaning"
  | "c10-similar-correspondence"
  | "c10-scale-factor"
  | "c10-proportional-sides"
  | "c10-aaa"
  | "c10-similarity-sss"
  | "c10-similarity-sas";

type PairMode =
  | "plain"
  | "angles"
  | "sides"
  | "sss"
  | "sas"
  | "asa"
  | "aas"
  | "similar"
  | "scale"
  | "proportional"
  | "aaa"
  | "similarity-sss"
  | "similarity-sas";

const diagramConfig: Record<Exclude<Chapter10FlashcardDiagramKind, "c10-rhs">, { mode: PairMode; caption: string }> = {
  "c10-congruent-meaning": { mode: "plain", caption: "Compare the two triangles." },
  "c10-correspondence": { mode: "plain", caption: "Use the order of the vertex names." },
  "c10-equal-angles": { mode: "plain", caption: "Compare the labelled congruent triangles." },
  "c10-equal-sides": { mode: "plain", caption: "Compare the labelled congruent triangles." },
  "c10-similar-angle-question": { mode: "similar", caption: "Compare the labelled similar triangles." },
  "c10-sss": { mode: "sss", caption: "Study the marked sides." },
  "c10-sas": { mode: "sas", caption: "Study the marked sides and angle." },
  "c10-asa": { mode: "asa", caption: "Study the marked angles and side." },
  "c10-aas": { mode: "aas", caption: "Study the marked angles and side." },
  "c10-similar-meaning": { mode: "similar", caption: "Compare the two triangles." },
  "c10-similar-correspondence": { mode: "similar", caption: "Use the order of the vertex names." },
  "c10-scale-factor": { mode: "scale", caption: "Compare the corresponding side lengths." },
  "c10-proportional-sides": { mode: "proportional", caption: "Compare the corresponding side lengths." },
  "c10-aaa": { mode: "aaa", caption: "Study the matching angle marks." },
  "c10-similarity-sss": { mode: "similarity-sss", caption: "Study the three side lengths." },
  "c10-similarity-sas": { mode: "similarity-sas", caption: "Study the marked angle and side lengths." },
};


export default function Chapter10FlashcardDiagram({kind}:{kind:Chapter10FlashcardDiagramKind}){
 const config=kind==="c10-rhs"?{mode:"rhs",caption:"Study the right-angle and side marks."}:diagramConfig[kind];
 const mode=config.mode==="scale"?"scale3":config.mode==="similarity-sss"?"proportional":config.mode==="similarity-sas"?"sas-proportional":config.mode;
 return <div style={{width:"100%",maxWidth:720,margin:"0 auto"}}><Pair mode={mode as import("@/components/maths/Chapter10Geometry").PairMode} topFirst/><p style={{textAlign:"center",fontSize:14,color:"#475569"}}>{config.caption}</p></div>;
}
