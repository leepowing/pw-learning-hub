"use client";
import { S2Chapter12Triangle } from "@/components/maths/S2Chapter12Triangle";
import { ReasonContent } from "@/components/maths/DualReason";


import S2Chapter11FlashcardDiagram, { type S2Chapter11DiagramKind } from "@/components/maths/S2Chapter11FlashcardDiagram";

// S2 Chapter 10 diagrams (additive integration).
import S2Chapter10FlashcardDiagram, { type S2Chapter10DiagramKind } from "@/components/maths/S2Chapter10FlashcardDiagram";


// S2 Chapter 9 diagrams (additive integration).
import S2Chapter9FlashcardDiagram, { type S2Chapter9DiagramKind } from "@/components/maths/S2Chapter9FlashcardDiagram";


// S2 Chapter 8 diagrams (additive integration).
import S2Chapter8FlashcardDiagram, { type S2Chapter8DiagramKind } from "@/components/maths/S2Chapter8FlashcardDiagram";


// S2 Chapter 7 diagrams (additive integration).
import S2Chapter7FlashcardDiagram, { type S2Chapter7DiagramKind } from "@/components/maths/S2Chapter7FlashcardDiagram";


// S2 Chapter 6 diagrams (additive integration).
import S2Chapter6FlashcardDiagram, { type S2Chapter6DiagramKind } from "@/components/maths/S2Chapter6FlashcardDiagram";


import { useEffect, useRef, useState } from "react";
import katex from "katex";

import type { MathsFlashcard } from "@/data/maths/flashcards";
import {
  getMathsFlashcardProgress,
  recordMathsFlashcardAnswer,
  syncMathsFlashcardProgress,
} from "@/lib/studentStorage";
import GeometryDiagram from "@/components/maths/GeometryDiagram";
import Chapter9FlashcardDiagram, { type Chapter9FlashcardDiagramKind } from "@/components/maths/Chapter9FlashcardDiagram";
import Chapter10FlashcardDiagram, { type Chapter10FlashcardDiagramKind } from "@/components/maths/Chapter10FlashcardDiagram";
import Chapter12FlashcardDiagram, { type Chapter12FlashcardDiagramKind } from "@/components/maths/Chapter12FlashcardDiagram";

type VisualMathsFlashcard = MathsFlashcard & {
  s2Chapter12Diagram?: boolean;
  frontDiagram?: Chapter9FlashcardDiagramKind;
  chapter10Diagram?: Chapter10FlashcardDiagramKind;
  chapter12Diagram?: Chapter12FlashcardDiagramKind;
  s2Chapter6Diagram?: S2Chapter6DiagramKind;
  s2Chapter11Diagram?: S2Chapter11DiagramKind;
  s2Chapter10Diagram?: S2Chapter10DiagramKind;
  s2Chapter9Diagram?: S2Chapter9DiagramKind;
  s2Chapter8Diagram?: S2Chapter8DiagramKind;
  s2Chapter7Diagram?: S2Chapter7DiagramKind;
};

type Props = {
  cards: VisualMathsFlashcard[];
  reviewMode?: boolean;
};
type ExitDirection = "left" | "right" | null;
type SaveStatus = "idle" | "saving" | "saved" | "error";

function MathFormula({ formula }: { formula: string }) {
  const html = katex.renderToString(formula, { throwOnError: false, displayMode: true });
  return <div style={{ overflowX: "auto", padding: 8, fontSize: 20 }} dangerouslySetInnerHTML={{ __html: html }} />;
}

export default function FormulaFlashcards({
  cards,
  reviewMode = false,
}: Props) {
  const [queue, setQueue] = useState<VisualMathsFlashcard[]>(cards);
  const [flipped, setFlipped] = useState(false);
  const [correct, setCorrect] = useState(0);
  const [practice, setPractice] = useState(0);
  const [dragOffset, setDragOffset] = useState(0);
  const [exitDirection, setExitDirection] = useState<ExitDirection>(null);
  const [progressReady, setProgressReady] = useState(false);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle");
  const dragStartX = useRef<number | null>(null);
  const didDrag = useRef(false);
  const latestSaveNumber = useRef(0);

  useEffect(() => {
    let active = true;

    async function prepareProgress() {
      try {
        await syncMathsFlashcardProgress();
      } catch (error) {
        console.error(
          "Could not sync maths flashcard progress:",
          error
        );
      } finally {
        if (active) {
          setProgressReady(true);
        }
      }
    }

    void prepareProgress();

    return () => { active = false; };
  }, []);

  const currentCard = queue[0];
  const totalAttempts = correct + practice;
  const accuracy = totalAttempts === 0 ? 0 : Math.round((correct / totalAttempts) * 100);

  function resetSession() {
    setQueue([...cards]);
    setFlipped(false);
    setCorrect(0);
    setPractice(0);
    setDragOffset(0);
    setExitDirection(null);
  }

  function gradeCard(result: "correct" | "practice") {
    if (!currentCard || !flipped || exitDirection !== null) return;

    const saveNumber = latestSaveNumber.current + 1;
    latestSaveNumber.current = saveNumber;
    setSaveStatus("saving");

    void recordMathsFlashcardAnswer(
      currentCard.id,
      result
    )
      .then((saved) => {
        if (latestSaveNumber.current === saveNumber) {
          setSaveStatus(saved ? "saved" : "error");
        }
      })
      .catch((error) => {
        console.error(
          "Could not save maths flashcard answer:",
          error
        );

        if (latestSaveNumber.current === saveNumber) {
          setSaveStatus("error");
        }
      });

    const updatedProgress =
      getMathsFlashcardProgress()[currentCard.id];

    const updatedAccuracy = updatedProgress?.attempts
      ? updatedProgress.correct / updatedProgress.attempts
      : result === "correct"
        ? 1
        : 0;

    const shouldRepeatCard =
      result === "practice" ||
      (reviewMode && updatedAccuracy < 0.8);

    setExitDirection(result === "correct" ? "left" : "right");

    window.setTimeout(() => {
      setQueue((currentQueue) => {
        const remainingCards = currentQueue.slice(1);

        return shouldRepeatCard
          ? [...remainingCards, currentQueue[0]]
          : remainingCards;
      });
      if (result === "correct") setCorrect((value) => value + 1);
      else setPractice((value) => value + 1);
      setFlipped(false);
      setDragOffset(0);
      setExitDirection(null);
    }, 350);
  }

  function handlePointerDown(event: React.PointerEvent<HTMLDivElement>) {
    if (!flipped || exitDirection !== null) return;
    dragStartX.current = event.clientX;
    didDrag.current = false;
  }

  function handlePointerMove(event: React.PointerEvent<HTMLDivElement>) {
    if (dragStartX.current === null || !flipped || exitDirection !== null) return;
    const distance = event.clientX - dragStartX.current;
    if (Math.abs(distance) > 8) didDrag.current = true;
    setDragOffset(distance);
  }

  function handlePointerUp() {
    if (dragStartX.current === null) return;
    dragStartX.current = null;
    if (dragOffset <= -90) return gradeCard("correct");
    if (dragOffset >= 90) return gradeCard("practice");
    setDragOffset(0);
  }

  if (cards.length === 0) {
    return <section style={messagePanel}><h2>No flashcards are available.</h2></section>;
  }

  if (!progressReady) {
    return <section style={messagePanel}><h2>Loading your progress...</h2><p style={{ color: "#6b7280" }}>Syncing flashcard records.</p></section>;
  }

  if (!currentCard) {
    return (
      <section style={{ ...messagePanel, background: "#ecfdf5", border: "1px solid #86efac" }}>
        <p style={{ margin: "0 0 8px", color: "#166534", fontWeight: 800, letterSpacing: 1 }}>SESSION COMPLETE</p>
        <h2 style={{ margin: "0 0 12px", fontSize: 38 }}>{correct} cards remembered</h2>
        <p style={{ marginBottom: 28, color: "#4b5563", fontSize: 18 }}>Accuracy: {accuracy}%</p>
        <button type="button" onClick={resetSession} style={primaryButton("#16a34a")}>Practise again</button>
      </section>
    );
  }

  const useContentSizedFaces = (currentCard.level === "s1" && (currentCard.chapter === 9 || currentCard.chapter === 10)) || currentCard.level === "s2" && (currentCard.chapter === 6 || currentCard.chapter === 7 || currentCard.chapter === 8 || currentCard.chapter === 9 || currentCard.chapter === 10 || currentCard.chapter === 11 || currentCard.chapter === 12);
  const hasFrontVisual = Boolean(currentCard.s2Chapter12Diagram || currentCard.frontDiagram || currentCard.chapter10Diagram || currentCard.chapter12Diagram || currentCard.s2Chapter6Diagram || currentCard.s2Chapter7Diagram || currentCard.s2Chapter8Diagram || currentCard.s2Chapter9Diagram || currentCard.s2Chapter10Diagram || currentCard.s2Chapter11Diagram);
  const cardOffset = exitDirection === "left" ? -900 : exitDirection === "right" ? 900 : dragOffset;

  return (
    <section>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginBottom: 24 }}>
        {[["Remaining", queue.length], ["Correct", correct], ["Need practice", practice], ["Accuracy", `${accuracy}%`]].map(([label, value]) => (
          <div key={label} style={{ padding: 16, borderRadius: 16, background: "white", border: "1px solid #e5e7eb", textAlign: "center" }}>
            <strong style={{ display: "block", fontSize: 24 }}>{value}</strong>
            <span style={{ color: "#6b7280" }}>{label}</span>
          </div>
        ))}
      </div>

      {saveStatus !== "idle" && (
        <div
          role={saveStatus === "error" ? "alert" : "status"}
          style={{
            marginBottom: 18,
            padding: "11px 16px",
            borderRadius: 14,
            textAlign: "center",
            fontWeight: 800,
            color:
              saveStatus === "error" ? "#9a3412" : "#166534",
            background:
              saveStatus === "error" ? "#fff7ed" : "#f0fdf4",
            border: `1px solid ${
              saveStatus === "error" ? "#fdba74" : "#86efac"
            }`,
          }}
        >
          {saveStatus === "saving" && "Saving progress..."}
          {saveStatus === "saved" && "Progress saved."}
          {saveStatus === "error" &&
            "Progress is saved on this device and will be uploaded during the next sync."}
        </div>
      )}

      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onClick={() => {
          if (didDrag.current) { didDrag.current = false; return; }
          if (exitDirection === null) setFlipped((value) => !value);
        }}
        style={{
          transform: `translateX(${cardOffset}px) rotate(${cardOffset / 40}deg)`,
          opacity: exitDirection === null ? 1 : 0,
          transition: dragStartX.current === null ? "transform 350ms ease, opacity 350ms ease" : "none",
          cursor: "pointer",
          touchAction: "pan-y",
          perspective: 1200,
        }}
      >
        <div style={{ position: "relative", display: useContentSizedFaces ? "grid" : undefined, minHeight: hasFrontVisual ? 560 : 430, transformStyle: "preserve-3d", transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)", transition: "transform 500ms ease" }}>
          <article style={{ ...cardFace("linear-gradient(135deg, #eef2ff, #ffffff)", "#c7d2fe"), ...(useContentSizedFaces ? { position: "relative" as const, inset: "auto", gridArea: "1 / 1", minWidth: 0, padding: "clamp(18px, 4vw, 34px)" } : {}) }}>
            <p style={{ color: "#4f46e5", fontWeight: 800, letterSpacing: 1 }}>{currentCard.level.toUpperCase()} · CHAPTER {currentCard.chapter}</p>
            {currentCard.s2Chapter12Diagram && <S2Chapter12Triangle />}
            {currentCard.frontDiagram && <Chapter9FlashcardDiagram kind={currentCard.frontDiagram} />}
            {currentCard.chapter10Diagram && <Chapter10FlashcardDiagram kind={currentCard.chapter10Diagram} />}
            {currentCard.chapter12Diagram && <Chapter12FlashcardDiagram kind={currentCard.chapter12Diagram} />}
            {currentCard.s2Chapter6Diagram && <S2Chapter6FlashcardDiagram kind={currentCard.s2Chapter6Diagram} />}
            {currentCard.s2Chapter11Diagram && <S2Chapter11FlashcardDiagram kind={currentCard.s2Chapter11Diagram} />}
            {currentCard.s2Chapter10Diagram && <S2Chapter10FlashcardDiagram kind={currentCard.s2Chapter10Diagram} />}
            {currentCard.s2Chapter9Diagram && <S2Chapter9FlashcardDiagram kind={currentCard.s2Chapter9Diagram} />}
            {currentCard.s2Chapter8Diagram && <S2Chapter8FlashcardDiagram kind={currentCard.s2Chapter8Diagram} />}
            {currentCard.s2Chapter7Diagram && <S2Chapter7FlashcardDiagram kind={currentCard.s2Chapter7Diagram} />}
            <h2 style={{ margin: hasFrontVisual ? "4px 0 10px" : undefined, fontSize: hasFrontVisual ? 28 : 34, lineHeight: 1.3 }}>{currentCard.prompt}</h2>
            <p style={{ color: "#6b7280" }}>Click the card to reveal the answer.</p>
          </article>

          <article style={{ ...cardFace("linear-gradient(135deg, #ecfdf5, #ffffff)", "#86efac"), transform: "rotateY(180deg)", overflow: "auto", ...(useContentSizedFaces ? { position: "relative" as const, inset: "auto", gridArea: "1 / 1", minWidth: 0, padding: "clamp(18px, 4vw, 34px)" } : {}) }}>
            <p style={{ color: "#15803d", fontWeight: 800, letterSpacing: 1 }}>ANSWER</p>
            {currentCard.diagram && <GeometryDiagram diagram={currentCard.diagram} />}
            {currentCard.formula && <MathFormula formula={currentCard.formula} />}
            {currentCard.answer && <h2>{currentCard.answer}</h2>}
            {currentCard.answerReason && <ReasonContent>{currentCard.answerReason}</ReasonContent>}
            {currentCard.explanation && <p style={{ margin: "18px auto 0", maxWidth: 680, color: "#4b5563", fontSize: 17, lineHeight: 1.6 }}><ReasonContent>{currentCard.explanation}</ReasonContent></p>}
          </article>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 22 }}>
        <button type="button" disabled={!flipped || exitDirection !== null} onClick={() => gradeCard("correct")} style={gradeButton(flipped, "#16a34a")}>← I remembered</button>
        <button type="button" disabled={!flipped || exitDirection !== null} onClick={() => gradeCard("practice")} style={gradeButton(flipped, "#f97316")}>I need more practice →</button>
      </div>
      {!flipped && <p style={{ textAlign: "center", color: "#6b7280", marginTop: 12 }}>Reveal the answer before grading this card.</p>}
    </section>
  );
}

const messagePanel = { padding: 36, borderRadius: 24, background: "white", textAlign: "center" as const };

function cardFace(background: string, borderColor: string) {
  return {
    position: "absolute" as const,
    inset: 0,
    padding: 34,
    borderRadius: 28,
    background,
    border: `2px solid ${borderColor}`,
    boxShadow: "0 18px 45px rgba(0,0,0,0.08)",
    backfaceVisibility: "hidden" as const,
    display: "flex",
    flexDirection: "column" as const,
    justifyContent: "center",
    textAlign: "center" as const,
  };
}

function primaryButton(background: string) {
  return { border: "none", borderRadius: 16, padding: "16px 32px", background, color: "white", fontSize: 18, fontWeight: 800, cursor: "pointer" };
}

function gradeButton(enabled: boolean, background: string) {
  return { border: "none", borderRadius: 18, padding: 18, background: enabled ? background : "#d1d5db", color: "white", fontSize: 18, fontWeight: 800, cursor: enabled ? "pointer" : "not-allowed" };
}
