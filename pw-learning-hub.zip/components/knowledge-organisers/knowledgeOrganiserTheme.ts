import type { CSSProperties } from "react";

type KnowledgeOrganiserTheme = CSSProperties & Record<`--ko-${string}`, string>;

const historyTheme: KnowledgeOrganiserTheme = {
  "--ko-primary": "#c2410c",
  "--ko-primary-dark": "#9a3412",
  "--ko-primary-deep": "#7c2d12",
  "--ko-primary-border": "#fdba74",
  "--ko-primary-border-strong": "#fb923c",
  "--ko-primary-soft": "#fff7ed",
  "--ko-primary-muted": "#ffedd5",
  "--ko-primary-ring": "#fed7aa",
  "--ko-primary-shadow": "rgba(194,65,12,.12)",
};

const scienceTheme: KnowledgeOrganiserTheme = {
  "--ko-primary": "#15803d",
  "--ko-primary-dark": "#166534",
  "--ko-primary-deep": "#14532d",
  "--ko-primary-border": "#86efac",
  "--ko-primary-border-strong": "#22c55e",
  "--ko-primary-soft": "#f0fdf4",
  "--ko-primary-muted": "#dcfce7",
  "--ko-primary-ring": "#bbf7d0",
  "--ko-primary-shadow": "rgba(21,128,61,.14)",
};

const englishTheme: KnowledgeOrganiserTheme = {
  "--ko-primary": "#9f1239",
  "--ko-primary-dark": "#881337",
  "--ko-primary-deep": "#4c0519",
  "--ko-primary-border": "#fda4af",
  "--ko-primary-border-strong": "#f43f5e",
  "--ko-primary-soft": "#fff1f2",
  "--ko-primary-muted": "#ffe4e6",
  "--ko-primary-ring": "#fecdd3",
  "--ko-primary-shadow": "rgba(159,18,57,.14)",
};

const geographyTheme: KnowledgeOrganiserTheme = {
  "--ko-primary": "#0f766e",
  "--ko-primary-dark": "#115e59",
  "--ko-primary-deep": "#134e4a",
  "--ko-primary-border": "#5eead4",
  "--ko-primary-border-strong": "#2dd4bf",
  "--ko-primary-soft": "#f0fdfa",
  "--ko-primary-muted": "#ccfbf1",
  "--ko-primary-ring": "#99f6e4",
  "--ko-primary-shadow": "rgba(15,118,110,.14)",
};

const designTechnologyTheme: KnowledgeOrganiserTheme = {
  "--ko-primary": "#65a30d",
  "--ko-primary-dark": "#3f6212",
  "--ko-primary-deep": "#365314",
  "--ko-primary-border": "#bef264",
  "--ko-primary-border-strong": "#84cc16",
  "--ko-primary-soft": "#f7fee7",
  "--ko-primary-muted": "#ecfccb",
  "--ko-primary-ring": "#d9f99d",
  "--ko-primary-shadow": "rgba(101,163,13,.14)",
};
const spanishTheme: KnowledgeOrganiserTheme = {"--ko-primary":"#7c3aed","--ko-primary-dark":"#6d28d9","--ko-primary-deep":"#4c1d95","--ko-primary-border":"#c4b5fd","--ko-primary-border-strong":"#8b5cf6","--ko-primary-soft":"#faf5ff","--ko-primary-muted":"#ede9fe","--ko-primary-ring":"#ddd6fe","--ko-primary-shadow":"rgba(124,58,237,.14)"};
const frenchTheme: KnowledgeOrganiserTheme = {"--ko-primary":"#2563eb","--ko-primary-dark":"#1d4ed8","--ko-primary-deep":"#1e3a8a","--ko-primary-border":"#93c5fd","--ko-primary-border-strong":"#3b82f6","--ko-primary-soft":"#eff6ff","--ko-primary-muted":"#dbeafe","--ko-primary-ring":"#bfdbfe","--ko-primary-shadow":"rgba(37,99,235,.14)"};

export function getKnowledgeOrganiserTheme(subject: string): KnowledgeOrganiserTheme {
  const normalisedSubject = subject.trim().toLowerCase();
  if (normalisedSubject === "science") return scienceTheme;
  if (normalisedSubject === "english") return englishTheme;
  if (normalisedSubject === "geography") return geographyTheme;
  if (normalisedSubject === "design technology") return designTechnologyTheme;
  if (normalisedSubject === "spanish") return spanishTheme;
  if (normalisedSubject === "french") return frenchTheme;
  return historyTheme;
}
